package com.example.project.dto;

import com.example.project.entity.ServiceRecord;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceRecordDTO {

    private Long id;

    @NotNull(message = "Service date is required")
    @PastOrPresent(message = "Service date cannot be in the future")
    private LocalDate serviceDate;

    @NotNull(message = "KM at service is required")
    @Min(value = 0, message = "KM at service cannot be negative")
    private Long kmAtService;

    @NotBlank(message = "Service type is required")
    private String serviceType;

    private String notes;

    private Long vehicleId;

    public static ServiceRecordDTO fromEntity(ServiceRecord record) {
        return new ServiceRecordDTO(
                record.getId(),
                record.getServiceDate(),
                record.getKmAtService(),
                record.getServiceType(),
                record.getNotes(),
                record.getVehicle().getId()
        );
    }
}
