package com.example.project.service;

import com.example.project.dto.VehicleDTO;
import com.example.project.entity.User;
import com.example.project.entity.Vehicle;
import com.example.project.repository.UserRepository;
import com.example.project.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private UserRepository userRepository;

    public VehicleDTO createVehicle(Long userId, VehicleDTO vehicleDTO) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + userId));

        Vehicle vehicle = new Vehicle();
        vehicle.setName(vehicleDTO.getName());
        vehicle.setModel(vehicleDTO.getModel());
        vehicle.setFuelType(vehicleDTO.getFuelType());
        vehicle.setPurchaseDate(vehicleDTO.getPurchaseDate());
        vehicle.setKmDriven(vehicleDTO.getKmDriven());
        vehicle.setUser(user);

        Vehicle savedVehicle = vehicleRepository.save(vehicle);
        return VehicleDTO.fromEntity(savedVehicle);
    }

    public VehicleDTO updateVehicle(Long vehicleId, VehicleDTO vehicleDTO) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));

        vehicle.setName(vehicleDTO.getName());
        vehicle.setModel(vehicleDTO.getModel());
        vehicle.setFuelType(vehicleDTO.getFuelType());
        vehicle.setPurchaseDate(vehicleDTO.getPurchaseDate());
        vehicle.setKmDriven(vehicleDTO.getKmDriven());

        Vehicle updatedVehicle = vehicleRepository.save(vehicle);
        return VehicleDTO.fromEntity(updatedVehicle);
    }

    public VehicleDTO getVehicleById(Long vehicleId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));
        return VehicleDTO.fromEntity(vehicle);
    }

    public List<VehicleDTO> getVehiclesByUserId(Long userId) {
        List<Vehicle> vehicles = vehicleRepository.findByUserId(userId);
        return vehicles.stream()
                .map(VehicleDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public void deleteVehicle(Long vehicleId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));
        vehicleRepository.delete(vehicle);
    }

    public Long getVehicleCount(Long userId) {
        return (long) vehicleRepository.findByUserId(userId).size();
    }
}
