# Car Maintenance Prediction System - Backend (Spring Boot)

## Project Overview
This is the backend REST API for the Car Maintenance Prediction System, built with Spring Boot, Spring Data JPA, MySQL, and JWT authentication.

## Technology Stack
- **Framework**: Spring Boot 4.0.4
- **Language**: Java 17
- **Database**: MySQL 8.0+
- **Authentication**: JWT (JSON Web Tokens)
- **Build Tool**: Maven
- **ORM**: Spring Data JPA with Hibernate

## Prerequisites
- Java 17 or higher
- MySQL 8.0 or higher
- Maven 3.6.0 or higher
- Git

## Project Structure
```
project/
├── src/main/java/com/example/project/
│   ├── controller/          # REST API controllers
│   ├── service/             # Business logic layer
│   ├── repository/          # Data access layer
│   ├── entity/              # JPA entities
│   ├── dto/                 # Data Transfer Objects
│   ├── security/            # JWT and Security configurations
│   ├── config/              # Spring Security configuration
│   └── ProjectApplication.java  # Main application class
├── src/main/resources/
│   ├── application.properties   # Application configuration
│   └── db-schema.sql           # Database schema
└── pom.xml                 # Maven configuration
```

## Installation & Setup

### Step 1: Clone the Repository
```bash
cd "d:\23EG107c04\Car Maintainance System\project"
```

### Step 2: Configure MySQL Database
1. Open MySQL command line or MySQL Workbench
2. Execute the script from `src/main/resources/db-schema.sql`:
   ```sql
   CREATE DATABASE IF NOT EXISTS car_maintenance_db;
   USE car_maintenance_db;
   -- Run all commands from db-schema.sql
   ```

### Step 3: Update Application Properties
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/car_maintenance_db
spring.datasource.username=root
spring.datasource.password=your_mysql_password
jwt.secret=your-secret-key-make-it-at-least-256-bits-long
jwt.expiration=86400000
```

### Step 4: Build the Project
```bash
mvn clean install
```

### Step 5: Run the Application
```bash
mvn spring-boot:run
```

The application will start at `http://localhost:8080`

## API Endpoints

### Authentication Endpoints
- **POST** `/api/auth/register` - Register a new user
  ```json
  {
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123"
  }
  ```

- **POST** `/api/auth/login` - Login user
  ```json
  {
    "email": "john@example.com",
    "password": "password123"
  }
  ```

### Vehicle Endpoints
- **POST** `/api/vehicles` - Create a new vehicle
- **GET** `/api/vehicles` - Get all vehicles for current user
- **GET** `/api/vehicles/{id}` - Get vehicle by ID
- **PUT** `/api/vehicles/{id}` - Update vehicle
- **DELETE** `/api/vehicles/{id}` - Delete vehicle

### Service Record Endpoints
- **POST** `/api/services/{vehicleId}` - Add service record
- **GET** `/api/services/vehicle/{vehicleId}` - Get all service records for vehicle
- **GET** `/api/services/{id}` - Get service record by ID
- **PUT** `/api/services/{id}` - Update service record
- **DELETE** `/api/services/{id}` - Delete service record

### Maintenance Prediction Endpoints
- **GET** `/api/prediction/{vehicleId}` - Get maintenance prediction for vehicle

### Dashboard Endpoints
- **GET** `/api/dashboard/summary` - Get dashboard summary

## Request/Response Examples

### Register User
**Request:**
```
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "type": "Bearer",
  "userId": 1,
  "email": "john@example.com",
  "name": "John Doe"
}
```

### Create Vehicle
**Request:**
```
POST /api/vehicles
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "My Car",
  "model": "Honda Civic 2020",
  "fuelType": "PETROL",
  "purchaseDate": "2020-05-15",
  "kmDriven": 12000
}
```

### Add Service Record
**Request:**
```
POST /api/services/1
Authorization: Bearer {token}
Content-Type: application/json

{
  "serviceDate": "2024-03-01",
  "kmAtService": 10000,
  "serviceType": "Regular Service",
  "notes": "Oil change and filter replacement"
}
```

### Get Maintenance Prediction
**Request:**
```
GET /api/prediction/1
Authorization: Bearer {token}
```

**Response:**
```json
{
  "vehicleId": 1,
  "vehicleName": "My Car",
  "riskLevel": "LOW",
  "recommendation": "Your vehicle is in good maintenance status.",
  "kmDrivenSinceLastService": 2000,
  "daysSinceLastService": 30,
  "lastServiceDate": "2024-03-01",
  "lastServiceKm": 10000,
  "vehicleAgeInYears": 4,
  "isServiceRequired": false
}
```

## Maintenance Prediction Logic

### Risk Levels
1. **LOW** - Vehicle is well maintained
   - KM driven since last service < 3500 km
   - Last service < 4.2 months (126 days)
   - Vehicle age < 5 years

2. **MEDIUM** - Service approaching
   - KM driven since last service: 3500-7500 km
   - Last service: 4.2-9 months (126-270 days)

3. **HIGH** - Immediate service required
   - KM driven since last service > 7500 km
   - Last service > 9 months (270 days)
   - Vehicle age > 5 years

### Service Thresholds
- Service required if: KM > 5000 OR Days > 180 (6 months)
- Additional risk if: Vehicle age > 5 years

## Security
- Passwords are encrypted using BCrypt
- JWT tokens expire in 24 hours
- CORS is configured for frontend communication
- All protected endpoints require valid JWT token in Authorization header

## Troubleshooting

### Database Connection Error
```
ERROR: Could not get a connection to the database
```
- Check MySQL is running
- Verify database credentials in application.properties
- Ensure database `car_maintenance_db` exists

### JWT Token Errors
- Ensure `jwt.secret` is configured in application.properties
- Check token is in format: `Authorization: Bearer {token}`
- Verify token hasn't expired (24 hours)

## Development Notes
- Hot reloading enabled via spring-boot-devtools
- Enable SQL logging by changing `spring.jpa.show-sql=true`
- Change JPA ddl-auto to 'validate' in production

## Future Enhancements
- Email notifications for service reminders
- Maintenance cost tracking
- Export service history to PDF
- Integration with OBD-II devices for real-time KM tracking
