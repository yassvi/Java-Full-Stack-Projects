package com.example.project.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintenancePredictionResponse {

    private Long vehicleId;
    private String vehicleName;
    private RiskLevel riskLevel;
    private String recommendation;
    private Long kmDrivenSinceLastService;
    private Integer daysSinceLastService;
    private LocalDate lastServiceDate;
    private Long lastServiceKm;
    private Integer vehicleAgeInYears;
    private Boolean isServiceRequired;

    public enum RiskLevel {
        LOW, MEDIUM, HIGH
    }
}
