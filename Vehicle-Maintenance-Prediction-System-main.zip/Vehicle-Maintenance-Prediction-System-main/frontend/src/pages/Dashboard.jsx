import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { vehicleAPI, predictionAPI } from '../services/api';
import { formatKilometers, getRiskLevelBadgeColor, showAlert } from '../utils/helpers';

const Dashboard = () => {
  const [vehicles, setVehicles] = useState([]);
  const [predictions, setPredictions] = useState({});
  const [loading, setLoading] = useState(true);
  const [user] = useState(JSON.parse(localStorage.getItem('user') || '{}'));

  useEffect(() => {
    fetchVehicles();
  }, []);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      const response = await vehicleAPI.getAll();
      setVehicles(response.data);

      // Fetch predictions for each vehicle
      for (const vehicle of response.data) {
        try {
          const predResponse = await predictionAPI.getPrediction(vehicle.id);
          setPredictions((prev) => ({
            ...prev,
            [vehicle.id]: predResponse.data,
          }));
        } catch (error) {
          console.error(`Failed to fetch prediction for vehicle ${vehicle.id}:`, error);
        }
      }
    } catch (error) {
      showAlert('Failed to load vehicles', 'error');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteVehicle = async (vehicleId) => {
    if (window.confirm('Are you sure you want to delete this vehicle?')) {
      try {
        await vehicleAPI.delete(vehicleId);
        setVehicles(vehicles.filter((v) => v.id !== vehicleId));
        showAlert('Vehicle deleted successfully', 'success');
      } catch (error) {
        showAlert('Failed to delete vehicle', 'error');
        console.error(error);
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading vehicles...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Vehicle Maintenance System</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">Welcome, {user.name}</span>
            <button
              onClick={handleLogout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
            <p className="text-gray-600 mt-1">Manage your vehicles and track maintenance</p>
          </div>
          <Link
            to="/add-vehicle"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition"
          >
            + Add Vehicle
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-gray-600 text-sm font-medium">Total Vehicles</div>
            <div className="text-3xl font-bold text-blue-600 mt-2">{vehicles.length}</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-gray-600 text-sm font-medium">Service Overdue</div>
            <div className="text-3xl font-bold text-red-600 mt-2">
              {vehicles.filter(
                (v) => predictions[v.id]?.riskLevel === 'HIGH'
              ).length}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-gray-600 text-sm font-medium">Up Coming Services</div>
            <div className="text-3xl font-bold text-yellow-600 mt-2">
              {vehicles.filter(
                (v) => predictions[v.id]?.riskLevel === 'MEDIUM'
              ).length}
            </div>
          </div>
        </div>

        {/* Vehicles Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Your Vehicles</h3>
          </div>

          {vehicles.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-gray-600 mb-4">No vehicles added yet</p>
              <Link
                to="/add-vehicle"
                className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition"
              >
                Add Your First Vehicle
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Vehicle Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Model
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      KM Driven
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Risk Level
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {vehicles.map((vehicle) => {
                    const prediction = predictions[vehicle.id];
                    return (
                      <tr key={vehicle.id} className="hover:bg-gray-50 transition">
                        <td className="px-6 py-4 whitespace-nowrap font-semibold text-gray-900">
                          {vehicle.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-600">{vehicle.model}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                          {formatKilometers(vehicle.kmDriven)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {prediction ? (
                            <span
                              className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${getRiskLevelBadgeColor(
                                prediction.riskLevel
                              )}`}
                            >
                              {prediction.riskLevel}
                            </span>
                          ) : (
                            <span className="text-gray-500">Loading...</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap space-x-2">
                          <Link
                            to={`/vehicle/${vehicle.id}`}
                            className="text-blue-600 hover:text-blue-800 font-semibold text-sm"
                          >
                            View
                          </Link>
                          <Link
                            to={`/prediction/${vehicle.id}`}
                            className="text-green-600 hover:text-green-800 font-semibold text-sm"
                          >
                            Prediction
                          </Link>
                          <button
                            onClick={() => handleDeleteVehicle(vehicle.id)}
                            className="text-red-600 hover:text-red-800 font-semibold text-sm"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
