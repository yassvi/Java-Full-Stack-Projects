import React from 'react';
import { Navigate } from 'react-router-dom';
import { tokenStorage } from '../utils/helpers';

const PrivateRoute = ({ children }) => {
  const isAuthenticated = tokenStorage.exists();

  return isAuthenticated ? children : <Navigate to="/login" />;
};

export default PrivateRoute;
