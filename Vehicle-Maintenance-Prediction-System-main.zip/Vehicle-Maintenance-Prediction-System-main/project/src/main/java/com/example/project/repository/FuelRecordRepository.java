package com.example.project.repository;

import com.example.project.entity.FuelRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FuelRecordRepository extends JpaRepository<FuelRecord, Long> {
    Optional<FuelRecord> findTopByVehicleIdOrderByOdometerReadingDesc(Long vehicleId);
    List<FuelRecord> findByVehicleIdOrderByFuelDateDescOdometerReadingDesc(Long vehicleId);
}
