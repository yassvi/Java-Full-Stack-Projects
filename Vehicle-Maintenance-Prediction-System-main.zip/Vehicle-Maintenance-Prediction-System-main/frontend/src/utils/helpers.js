// Date formatting utilities
export const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const getDaysSince = (dateString) => {
  if (!dateString) return null;
  const date = new Date(dateString);
  const today = new Date();
  const diffTime = Math.abs(today - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Risk level colors
export const getRiskLevelColor = (riskLevel) => {
  switch (riskLevel?.toUpperCase()) {
    case 'LOW':
      return 'text-green-600 bg-green-50';
    case 'MEDIUM':
      return 'text-yellow-600 bg-yellow-50';
    case 'HIGH':
      return 'text-red-600 bg-red-50';
    default:
      return 'text-gray-600 bg-gray-50';
  }
};

export const getRiskLevelBadgeColor = (riskLevel) => {
  switch (riskLevel?.toUpperCase()) {
    case 'LOW':
      return 'bg-green-500';
    case 'MEDIUM':
      return 'bg-yellow-500';
    case 'HIGH':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
};

// Fuel type display
export const formatFuelType = (fuelType) => {
  if (!fuelType) return '';
  return fuelType.charAt(0).toUpperCase() + fuelType.slice(1).toLowerCase();
};

// Number formatting
export const formatKilometers = (km) => {
  if (!km) return '0 km';
  return `${km.toLocaleString()} km`;
};

// Alert/Toast messaging
export const showAlert = (message, type = 'info') => {
  const alertDiv = document.createElement('div');
  alertDiv.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white ${
    type === 'success' ? 'bg-green-500' :
    type === 'error' ? 'bg-red-500' :
    type === 'warning' ? 'bg-yellow-500' :
    'bg-blue-500'
  } shadow-lg z-50`;
  alertDiv.textContent = message;
  document.body.appendChild(alertDiv);
  
  setTimeout(() => {
    alertDiv.remove();
  }, 3000);
};

// Validation helpers
export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validatePassword = (password) => {
  return password && password.length >= 6;
};

// Local storage helpers
export const tokenStorage = {
  get: () => localStorage.getItem('token'),
  set: (token) => localStorage.setItem('token', token),
  remove: () => localStorage.removeItem('token'),
  exists: () => !!localStorage.getItem('token'),
};

export const userStorage = {
  get: () => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },
  set: (user) => localStorage.setItem('user', JSON.stringify(user)),
  remove: () => localStorage.removeItem('user'),
};
