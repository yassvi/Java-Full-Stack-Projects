package com.example.project.service;

import com.example.project.dto.FuelRecordDTO;
import com.example.project.entity.FuelRecord;
import com.example.project.entity.Vehicle;
import com.example.project.repository.FuelRecordRepository;
import com.example.project.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class FuelRecordService {

    @Autowired
    private FuelRecordRepository fuelRecordRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    public FuelRecordDTO addFuelRecord(Long vehicleId, FuelRecordDTO dto) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));

        if (dto.getLiters() == null || dto.getLiters() <= 0) {
            throw new IllegalArgumentException("Liters must be greater than 0");
        }

        if (dto.getOdometerReading() == null || dto.getOdometerReading() < 0) {
            throw new IllegalArgumentException("Odometer reading cannot be negative");
        }

        Optional<FuelRecord> lastRecord = fuelRecordRepository.findTopByVehicleIdOrderByOdometerReadingDesc(vehicleId);

        double mileage;
        if (lastRecord.isPresent()) {
            double distance = dto.getOdometerReading() - lastRecord.get().getOdometerReading();
            if (distance <= 0) {
                throw new IllegalArgumentException("Odometer reading must be greater than the previous fuel entry");
            }
            mileage = distance / dto.getLiters();
        } else {
            mileage = 0.0;
        }

        FuelRecord record = new FuelRecord();
        record.setVehicle(vehicle);
        record.setFuelDate(dto.getFuelDate());
        record.setLiters(dto.getLiters());
        record.setOdometerReading(dto.getOdometerReading());
        record.setMileage(mileage);

        FuelRecord savedRecord = fuelRecordRepository.save(record);
        return FuelRecordDTO.fromEntity(savedRecord);
    }

    public List<FuelRecordDTO> getFuelRecordsByVehicle(Long vehicleId) {
        vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));

        return fuelRecordRepository.findByVehicleIdOrderByFuelDateDescOdometerReadingDesc(vehicleId)
                .stream()
                .map(FuelRecordDTO::fromEntity)
                .collect(Collectors.toList());
    }
}
