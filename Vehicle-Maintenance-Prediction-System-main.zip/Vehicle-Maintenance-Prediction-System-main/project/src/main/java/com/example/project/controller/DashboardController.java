package com.example.project.controller;

import com.example.project.dto.VehicleDTO;
import com.example.project.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DashboardController {

    @Autowired
    private VehicleService vehicleService;

    @GetMapping("/summary")
    public ResponseEntity<?> getDashboardSummary() {
        try {
            String email = SecurityContextHolder.getContext().getAuthentication().getName();
            Long userId = extractUserIdFromEmail(email);

            List<VehicleDTO> vehicles = vehicleService.getVehiclesByUserId(userId);
            Long vehicleCount = vehicleService.getVehicleCount(userId);

            Map<String, Object> summary = new HashMap<>();
            summary.put("totalVehicles", vehicleCount);
            summary.put("vehicles", vehicles);
            summary.put("upcomingServices", 0); // This would require additional logic

            return new ResponseEntity<>(summary, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    private Long extractUserIdFromEmail(String email) {
        // This is a placeholder - in production, extract from JWT token
        return 1L;
    }

    public static class ErrorResponse {
        public String message;
        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}
