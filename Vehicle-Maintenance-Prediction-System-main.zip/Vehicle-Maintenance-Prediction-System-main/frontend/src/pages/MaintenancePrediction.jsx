import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { predictionAPI, vehicleAPI } from '../services/api';
import { formatDate, formatKilometers, getRiskLevelColor, showAlert } from '../utils/helpers';

const MaintenancePrediction = () => {
  const { vehicleId } = useParams();
  const navigate = useNavigate();

  const [prediction, setPrediction] = useState(null);
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [vehicleId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const predRes = await predictionAPI.getPrediction(vehicleId);
      setPrediction(predRes.data);

      const vehicleRes = await vehicleAPI.getById(vehicleId);
      setVehicle(vehicleRes.data);
    } catch (error) {
      showAlert('Failed to load prediction data', 'error');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading prediction...</p>
        </div>
      </div>
    );
  }

  if (!prediction) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Prediction data not available</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const getRiskColor = (risk) => {
    switch (risk?.toUpperCase()) {
      case 'LOW':
        return 'text-green-600 bg-green-50';
      case 'MEDIUM':
        return 'text-yellow-600 bg-yellow-50';
      case 'HIGH':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getRiskIcon = (risk) => {
    switch (risk?.toUpperCase()) {
      case 'LOW':
        return '✓';
      case 'MEDIUM':
        return '!';
      case 'HIGH':
        return '✕';
      default:
        return '?';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-blue-600 hover:text-blue-800 font-semibold"
          >
            ← Back to Dashboard
          </button>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{vehicle?.name}</h1>
          <p className="text-gray-600 mt-1">Maintenance Prediction Report</p>
        </div>

        {/* Risk Level Card */}
        <div className={`rounded-lg shadow-md p-8 mb-8 ${getRiskColor(prediction.riskLevel)}`}>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Risk Level</h2>
              <div className="text-5xl font-bold opacity-20">{getRiskIcon(prediction.riskLevel)}</div>
            </div>
            <div className="text-6xl font-bold">{prediction.riskLevel}</div>
          </div>
        </div>

        {/* Recommendation */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Recommendation</h3>
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
            <p className="text-gray-700 leading-relaxed">{prediction.recommendation}</p>
          </div>
        </div>

        {/* Service Status */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Service Status</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-gray-600 text-sm font-medium mb-2">Service Required</p>
              <p className="text-3xl font-bold text-gray-900">
                {prediction.isServiceRequired ? 'YES' : 'NO'}
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-gray-600 text-sm font-medium mb-2">KM Since Last Service</p>
              <p className="text-3xl font-bold text-gray-900">
                {prediction.kmDrivenSinceLastService ? formatKilometers(prediction.kmDrivenSinceLastService) : 'N/A'}
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <p className="text-gray-600 text-sm font-medium mb-2">Days Since Last Service</p>
              <p className="text-3xl font-bold text-gray-900">
                {prediction.daysSinceLastService || 'N/A'}
              </p>
            </div>
          </div>
        </div>

        {/* Last Service Details */}
        {prediction.lastServiceDate && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Last Service Details</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-600 text-sm font-medium">Last Service Date</p>
                <p className="text-lg font-semibold text-gray-900 mt-1">
                  {formatDate(prediction.lastServiceDate)}
                </p>
              </div>

              <div>
                <p className="text-gray-600 text-sm font-medium">KM at Last Service</p>
                <p className="text-lg font-semibold text-gray-900 mt-1">
                  {formatKilometers(prediction.lastServiceKm)}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Vehicle Information */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Vehicle Information</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-gray-600 text-sm font-medium">Model</p>
              <p className="text-lg font-semibold text-gray-900 mt-1">{vehicle?.model}</p>
            </div>

            <div>
              <p className="text-gray-600 text-sm font-medium">Fuel Type</p>
              <p className="text-lg font-semibold text-gray-900 mt-1">{vehicle?.fuelType}</p>
            </div>

            <div>
              <p className="text-gray-600 text-sm font-medium">Vehicle Age</p>
              <p className="text-lg font-semibold text-gray-900 mt-1">
                {prediction.vehicleAgeInYears} years
              </p>
            </div>

            <div>
              <p className="text-gray-600 text-sm font-medium">Current Kilometers</p>
              <p className="text-lg font-semibold text-gray-900 mt-1">
                {formatKilometers(vehicle?.kmDriven)}
              </p>
            </div>
          </div>
        </div>

        {/* Thresholds Information */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h4 className="text-lg font-semibold text-blue-900 mb-4">Service Thresholds</h4>
          <ul className="space-y-2 text-blue-900">
            <li className="flex items-center">
              <span className="text-lg mr-3">•</span>
              <span>Service required if KM driven since last service exceeds 5,000 km</span>
            </li>
            <li className="flex items-center">
              <span className="text-lg mr-3">•</span>
              <span>Service recommended if more than 6 months (180 days) have passed</span>
            </li>
            <li className="flex items-center">
              <span className="text-lg mr-3">•</span>
              <span>Higher risk if vehicle age exceeds 5 years</span>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
};

export default MaintenancePrediction;
