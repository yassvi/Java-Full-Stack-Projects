import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import AddVehicle from './pages/AddVehicle';
import VehicleDetails from './pages/VehicleDetails';
import MaintenancePrediction from './pages/MaintenancePrediction';
import FuelTracker from './pages/FuelTracker';
import PrivateRoute from './components/PrivateRoute';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-vehicle"
          element={
            <PrivateRoute>
              <AddVehicle />
            </PrivateRoute>
          }
        />
        <Route
          path="/vehicle/:vehicleId"
          element={
            <PrivateRoute>
              <VehicleDetails />
            </PrivateRoute>
          }
        />
        <Route
          path="/prediction/:vehicleId"
          element={
            <PrivateRoute>
              <MaintenancePrediction />
            </PrivateRoute>
          }
        />
        <Route
          path="/fuel/:vehicleId"
          element={
            <PrivateRoute>
              <FuelTracker />
            </PrivateRoute>
          }
        />
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
