package com.example.project.service;

import com.example.project.dto.ServiceRecordDTO;
import com.example.project.entity.ServiceRecord;
import com.example.project.entity.Vehicle;
import com.example.project.repository.ServiceRecordRepository;
import com.example.project.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ServiceRecordService {

    @Autowired
    private ServiceRecordRepository serviceRecordRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    public ServiceRecordDTO createServiceRecord(Long vehicleId, ServiceRecordDTO recordDTO) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));

        ServiceRecord record = new ServiceRecord();
        record.setServiceDate(recordDTO.getServiceDate());
        record.setKmAtService(recordDTO.getKmAtService());
        record.setServiceType(recordDTO.getServiceType());
        record.setNotes(recordDTO.getNotes());
        record.setVehicle(vehicle);

        ServiceRecord savedRecord = serviceRecordRepository.save(record);
        return ServiceRecordDTO.fromEntity(savedRecord);
    }

    public ServiceRecordDTO updateServiceRecord(Long recordId, ServiceRecordDTO recordDTO) {
        ServiceRecord record = serviceRecordRepository.findById(recordId)
                .orElseThrow(() -> new IllegalArgumentException("Service record not found with id: " + recordId));

        record.setServiceDate(recordDTO.getServiceDate());
        record.setKmAtService(recordDTO.getKmAtService());
        record.setServiceType(recordDTO.getServiceType());
        record.setNotes(recordDTO.getNotes());

        ServiceRecord updatedRecord = serviceRecordRepository.save(record);
        return ServiceRecordDTO.fromEntity(updatedRecord);
    }

    public ServiceRecordDTO getServiceRecordById(Long recordId) {
        ServiceRecord record = serviceRecordRepository.findById(recordId)
                .orElseThrow(() -> new IllegalArgumentException("Service record not found with id: " + recordId));
        return ServiceRecordDTO.fromEntity(record);
    }

    public List<ServiceRecordDTO> getServiceRecordsByVehicleId(Long vehicleId) {
        List<ServiceRecord> records = serviceRecordRepository.findByVehicleId(vehicleId);
        return records.stream()
                .map(ServiceRecordDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public void deleteServiceRecord(Long recordId) {
        ServiceRecord record = serviceRecordRepository.findById(recordId)
                .orElseThrow(() -> new IllegalArgumentException("Service record not found with id: " + recordId));
        serviceRecordRepository.delete(record);
    }
}
