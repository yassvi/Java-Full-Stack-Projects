package com.example.project.service;

import com.example.project.dto.MaintenancePredictionResponse;
import com.example.project.entity.ServiceRecord;
import com.example.project.entity.Vehicle;
import com.example.project.repository.ServiceRecordRepository;
import com.example.project.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.Optional;

@Service
public class MaintenancePredictionService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private ServiceRecordRepository serviceRecordRepository;

    private static final long KM_SERVICE_THRESHOLD = 5000;
    private static final int MONTHS_SERVICE_THRESHOLD = 6;
    private static final int VEHICLE_AGE_THRESHOLD = 5;

    public MaintenancePredictionResponse predictMaintenance(Long vehicleId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with id: " + vehicleId));

        Optional<ServiceRecord> latestService = serviceRecordRepository.findLatestByVehicleId(vehicleId);

        MaintenancePredictionResponse response = new MaintenancePredictionResponse();
        response.setVehicleId(vehicleId);
        response.setVehicleName(vehicle.getName());

        LocalDate today = LocalDate.now();
        int vehicleAgeInYears = Period.between(vehicle.getPurchaseDate(), today).getYears();
        response.setVehicleAgeInYears(vehicleAgeInYears);

        if (latestService.isEmpty()) {
            // No service history - HIGH RISK
            response.setRiskLevel(MaintenancePredictionResponse.RiskLevel.HIGH);
            response.setRecommendation("This vehicle has never been serviced. Immediate service is required!");
            response.setIsServiceRequired(true);
            response.setKmDrivenSinceLastService(vehicle.getKmDriven());
            response.setDaysSinceLastService(null);
            response.setLastServiceDate(null);
            response.setLastServiceKm(null);
        } else {
            ServiceRecord latest = latestService.get();
            response.setLastServiceDate(latest.getServiceDate());
            response.setLastServiceKm(latest.getKmAtService());

            long kmDrivenSinceService = vehicle.getKmDriven() - latest.getKmAtService();
            response.setKmDrivenSinceLastService(kmDrivenSinceService);

            int daysSinceService = Period.between(latest.getServiceDate(), today).getDays();
            response.setDaysSinceLastService(daysSinceService);

            // Check service conditions
            boolean kmThresholdExceeded = kmDrivenSinceService > KM_SERVICE_THRESHOLD;
            boolean timeThresholdExceeded = daysSinceService > (MONTHS_SERVICE_THRESHOLD * 30);
            boolean vehicleAgeThresholdExceeded = vehicleAgeInYears > VEHICLE_AGE_THRESHOLD;

            response.setIsServiceRequired(kmThresholdExceeded || timeThresholdExceeded);

            // Determine risk level
            MaintenancePredictionResponse.RiskLevel riskLevel = determineRiskLevel(
                    kmDrivenSinceService, daysSinceService, vehicleAgeThresholdExceeded
            );
            response.setRiskLevel(riskLevel);

            // Generate recommendation
            String recommendation = generateRecommendation(
                    kmThresholdExceeded, timeThresholdExceeded, 
                    vehicleAgeThresholdExceeded, riskLevel, kmDrivenSinceService, daysSinceService
            );
            response.setRecommendation(recommendation);
        }

        return response;
    }

    private MaintenancePredictionResponse.RiskLevel determineRiskLevel(
            long kmDrivenSinceService, int daysSinceService, boolean vehicleAgeThresholdExceeded) {

        boolean kmCritical = kmDrivenSinceService > KM_SERVICE_THRESHOLD * 1.5;
        boolean timeCritical = daysSinceService > (MONTHS_SERVICE_THRESHOLD * 30 * 1.5);

        if (kmCritical || timeCritical || vehicleAgeThresholdExceeded) {
            return MaintenancePredictionResponse.RiskLevel.HIGH;
        }

        boolean kmModerate = kmDrivenSinceService > KM_SERVICE_THRESHOLD * 0.7;
        boolean timeModerate = daysSinceService > (MONTHS_SERVICE_THRESHOLD * 30 * 0.7);

        if (kmModerate || timeModerate) {
            return MaintenancePredictionResponse.RiskLevel.MEDIUM;
        }

        return MaintenancePredictionResponse.RiskLevel.LOW;
    }

    private String generateRecommendation(
            boolean kmThresholdExceeded, boolean timeThresholdExceeded,
            boolean vehicleAgeThresholdExceeded, MaintenancePredictionResponse.RiskLevel riskLevel,
            long kmDrivenSinceService, int daysSinceService) {

        StringBuilder recommendation = new StringBuilder();

        switch (riskLevel) {
            case HIGH:
                recommendation.append("URGENT: Your vehicle requires immediate servicing. ");
                break;
            case MEDIUM:
                recommendation.append("ATTENTION: Your vehicle is due for servicing soon. ");
                break;
            case LOW:
                recommendation.append("Your vehicle is in good maintenance status. ");
                break;
        }

        if (kmThresholdExceeded) {
            recommendation.append("KM driven since last service (").append(kmDrivenSinceService)
                    .append(" km) exceeds the recommended threshold (5000 km). ");
        }

        if (timeThresholdExceeded) {
            recommendation.append("Last service was ").append(daysSinceService)
                    .append(" days ago, which exceeds the recommended 6-month interval. ");
        }

        if (vehicleAgeThresholdExceeded) {
            recommendation.append("Your vehicle is over 5 years old and may require more frequent servicing. ");
        }

        if (!kmThresholdExceeded && !timeThresholdExceeded && !vehicleAgeThresholdExceeded) {
            recommendation.append("Continue regular maintenance as per schedule.");
        }

        return recommendation.toString();
    }
}
