package com.example.project.dto;

import com.example.project.entity.FuelRecord;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FuelRecordDTO {

    private Long id;

    @NotNull(message = "Fuel date is required")
    @PastOrPresent(message = "Fuel date cannot be in the future")
    private LocalDate fuelDate;

    @NotNull(message = "Liters is required")
    @DecimalMin(value = "0.000001", message = "Liters must be greater than 0")
    private Double liters;

    @NotNull(message = "Odometer reading is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Odometer reading cannot be negative")
    private Double odometerReading;

    private Double mileage;

    private Long vehicleId;

    public static FuelRecordDTO fromEntity(FuelRecord record) {
        return new FuelRecordDTO(
                record.getId(),
                record.getFuelDate(),
                record.getLiters(),
                record.getOdometerReading(),
                record.getMileage(),
                record.getVehicle().getId()
        );
    }
}
