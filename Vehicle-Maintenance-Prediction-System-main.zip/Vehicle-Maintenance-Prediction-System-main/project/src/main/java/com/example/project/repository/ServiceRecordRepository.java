package com.example.project.repository;

import com.example.project.entity.ServiceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceRecordRepository extends JpaRepository<ServiceRecord, Long> {
    List<ServiceRecord> findByVehicleId(Long vehicleId);
    
    @Query("SELECT sr FROM ServiceRecord sr WHERE sr.vehicle.id = :vehicleId ORDER BY sr.serviceDate DESC LIMIT 1")
    Optional<ServiceRecord> findLatestByVehicleId(@Param("vehicleId") Long vehicleId);
}
