# Car Maintenance Prediction System - Frontend (React.js)

## Project Overview
This is the modern, responsive React.js frontend for the Car Maintenance Prediction System. Built with Vite, React Router, Axios, and Tailwind CSS.

## Technology Stack
- **Framework**: React.js 19.2.4 with Hooks
- **Build Tool**: Vite 8.0.1
- **Routing**: React Router DOM 6.20.0
- **HTTP Client**: Axios 1.6.2
- **Styling**: Tailwind CSS 3.4.0
- **Charts**: Chart.js & React Chart.js 2

## Project Structure
```
frontend/
├── src/
│   ├── pages/              # Page components
│   │   ├── Login.jsx       # Login page
│   │   ├── Register.jsx    # Registration page
│   │   ├── Dashboard.jsx   # Main dashboard
│   │   ├── AddVehicle.jsx  # Add vehicle form
│   │   ├── VehicleDetails.jsx  # Vehicle details & service history
│   │   └── MaintenancePrediction.jsx  # Maintenance prediction
│   ├── components/         # Reusable components
│   │   └── PrivateRoute.jsx  # Protected routes
│   ├── services/           # API services
│   │   └── api.js         # Axios API configuration
│   ├── utils/              # Utility functions
│   │   └── helpers.js     # Helper functions
│   ├── App.jsx            # Main app with routing
│   ├── main.jsx           # React entry point
│   ├── index.css          # Global styles
│   └── App.css            # App styles
├── public/                 # Static assets
├── index.html             # HTML template
├── package.json           # Dependencies
├── vite.config.js         # Vite configuration
├── tailwind.config.js     # Tailwind configuration
└── postcss.config.js      # PostCSS configuration
```

## Prerequisites
- Node.js 16.0.0 or higher
- npm or yarn
- Car Maintenance Backend running on `http://localhost:8080`

## Installation & Setup

### Step 1: Navigate to Frontend Directory
```bash
cd "d:\23EG107c04\Car Maintainance System\frontend"
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure API Base URL (Optional)
By default, API calls go to `http://localhost:8080/api`. To change this, edit `src/services/api.js`:
```javascript
const API_BASE_URL = 'http://localhost:8080/api';
```

### Step 4: Start Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

## Available Scripts

### Development
```bash
npm run dev
```
Runs the app in development mode with hot reloading.

### Build for Production
```bash
npm run build
```
Creates an optimized production build.

### Preview Production Build
```bash
npm run preview
```
Serves the production build locally for testing.

### Lint Code
```bash
npm run lint
```
Runs ESLint to check code quality.

## Pages & Features

### 1. Login Page (`/login`)
- Email and password authentication
- JWT token management
- Form validation
- Redirect to dashboard on successful login

### 2. Register Page (`/register`)
- User registration with name, email, and password
- Form validation (email format, password strength, confirm password)
- Automatic login after registration
- Link to login page for existing users

### 3. Dashboard (`/dashboard`)
- View all vehicles
- Display vehicle risk levels (Low/Medium/High)
- Statistics: Total vehicles, overdue services, upcoming services
- Add new vehicle button
- Quick actions: View, Prediction, Delete for each vehicle
- Logout functionality

### 4. Add Vehicle (`/add-vehicle`)
- Form to add a new vehicle
  - Vehicle name
  - Model
  - Fuel type (Petrol/Diesel/Electric)
  - Purchase date
  - Current kilometers driven
- Form validation
- Auto-redirect to dashboard after adding

### 5. Vehicle Details (`/vehicle/:vehicleId`)
- Vehicle information display
- Service history table
- Add new service record form
  - Service date
  - Kilometers at service
  - Service type
  - Notes
- Delete service records
- Link to maintenance prediction

### 6. Maintenance Prediction (`/prediction/:vehicleId`)
- Risk level display (Low/Medium/High) with visual indicators
- Maintenance recommendations
- Service status information
- Last service details
- Vehicle information summary
- Service thresholds explanation

## API Integration

All API calls are managed through `src/services/api.js`:

### Authentication APIs
```javascript
authAPI.register(data)    // POST /auth/register
authAPI.login(data)       // POST /auth/login
```

### Vehicle APIs
```javascript
vehicleAPI.create(data)         // POST /vehicles
vehicleAPI.getAll()             // GET /vehicles
vehicleAPI.getById(id)          // GET /vehicles/{id}
vehicleAPI.update(id, data)     // PUT /vehicles/{id}
vehicleAPI.delete(id)           // DELETE /vehicles/{id}
```

### Service APIs
```javascript
serviceAPI.create(vehicleId, data)        // POST /services/{vehicleId}
serviceAPI.getByVehicle(vehicleId)        // GET /services/vehicle/{vehicleId}
serviceAPI.getById(id)                    // GET /services/{id}
serviceAPI.update(id, data)               // PUT /services/{id}
serviceAPI.delete(id)                     // DELETE /services/{id}
```

### Prediction APIs
```javascript
predictionAPI.getPrediction(vehicleId)    // GET /prediction/{vehicleId}
```

## State Management

Uses React Hooks for state management:
- `useState`: For component state
- `useEffect`: For side effects and API calls
- `useNavigate`: For programmatic navigation
- `useParams`: For route parameters

## Authentication & Security

- JWT tokens stored in localStorage
- Automatic token injection in API requests
- Protected routes using PrivateRoute component
- Automatic redirect to login on token expiry
- XHR interceptors for unauthorized responses

## Styling

### Tailwind CSS Classes Used
- Grid layouts for responsive design
- Flexbox for component alignment
- Color utilities (blue, green, yellow, red, gray)
- Spacing utilities (padding, margin, gap)
- Typography utilities (text colors, font weights)
- Hover and transition states

### Color Scheme
- **Primary**: Blue (#3b82f6)
- **Secondary**: Green (#10b981)
- **Danger**: Red (#ef4444)
- **Warning**: Yellow (#f59e0b)
- **Background**: Light gray (#f3f4f6)

## Form Validation

All forms include:
- Required field validation
- Email format validation
- Password strength validation
- Min/Max length validation
- Date validation
- Number validation
- Error messages displayed to user

## Error Handling

- Try-catch blocks for API calls
- User-friendly error messages
- Toast/Alert notifications
- Error logging in console
- Automatic redirect on 401 (Unauthorized) responses

## Responsive Design

- Mobile-first approach
- Tailwind breakpoints (sm, md, lg, xl)
- Responsive grid layouts
- Mobile-friendly forms and buttons
- Touch-friendly interface

## Helper Functions (`src/utils/helpers.js`)

### Date Utilities
- `formatDate(dateString)` - Format dates to readable format
- `getDaysSince(dateString)` - Calculate days since a date

### Display Utilities
- `getRiskLevelColor(riskLevel)` - Get color for risk level
- `getRiskLevelBadgeColor(riskLevel)` - Get badge color
- `formatFuelType(fuelType)` - Format fuel type text
- `formatKilometers(km)` - Format kilometers with commas

### Validation Utilities
- `validateEmail(email)` - Email regex validation
- `validatePassword(password)` - Password strength check

### Storage Utilities
- `tokenStorage` - Manage auth token in localStorage
- `userStorage` - Manage user data in localStorage

### UI Utilities
- `showAlert(message, type)` - Display toast notifications

## Development Tips

### Debugging
1. Use React DevTools browser extension
2. Check localStorage for stored tokens
3. Monitor Network tab in browser DevTools
4. Check browser console for errors

### Hot Reloading
- Changes are automatically reflected in browser
- State is preserved during HMR
- Fast refresh for quick development

### Building
- Production build optimizes code and assets
- Minifies CSS and JavaScript
- Tree shaking removes unused code
- Build output in `dist/` directory

## Troubleshooting

### API Connection Errors
```
Error: Cannot connect to backend
```
- Ensure backend is running on `http://localhost:8080`
- Check CORS configuration in backend
- Verify API_BASE_URL in `src/services/api.js`

### Authentication Issues
```
Token expired or invalid
```
- Clear localStorage and login again
- Check token expiration time in backend
- Verify JWT secret key matches backend

### Form Validation Errors
- Ensure all required fields are filled
- Check field format (email, date, numbers)
- Look for error messages under each field

### Styling Issues
- Clear browser cache
- Restart dev server
- Check Tailwind CSS purging is disabled in dev

## Future Enhancements

- Email notification preferences
- Export service history to PDF
- Maintenance cost tracking and analytics
- Calendar view for service schedules
- Vehicle documents upload
- Service provider management
- Parts inventory tracking
- Fuel efficiency tracking

## Deployment

### Deploy to Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Deploy to Netlify
```bash
npm install -g netlify-cli
netlify deploy --prod
```

### Build for Self-Hosting
```bash
npm run build
# Upload 'dist' folder to your server
```

## Support

For issues or questions:
1. Check the browser console for errors
2. Verify backend is running
3. Clear browser cache and localStorage
4. Try in a different browser
5. Check CORS headers
