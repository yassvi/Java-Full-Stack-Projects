package com.example.project.controller;

import com.example.project.dto.ServiceRecordDTO;
import com.example.project.service.ServiceRecordService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ServiceRecordController {

    @Autowired
    private ServiceRecordService serviceRecordService;

    @PostMapping("/{vehicleId}")
    public ResponseEntity<?> createServiceRecord(
            @PathVariable Long vehicleId,
            @Valid @RequestBody ServiceRecordDTO recordDTO) {
        try {
            ServiceRecordDTO created = serviceRecordService.createServiceRecord(vehicleId, recordDTO);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<?> getServiceRecordsByVehicleId(@PathVariable Long vehicleId) {
        try {
            List<ServiceRecordDTO> records = serviceRecordService.getServiceRecordsByVehicleId(vehicleId);
            return new ResponseEntity<>(records, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getServiceRecordById(@PathVariable Long id) {
        try {
            ServiceRecordDTO record = serviceRecordService.getServiceRecordById(id);
            return new ResponseEntity<>(record, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateServiceRecord(
            @PathVariable Long id,
            @Valid @RequestBody ServiceRecordDTO recordDTO) {
        try {
            ServiceRecordDTO updated = serviceRecordService.updateServiceRecord(id, recordDTO);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteServiceRecord(@PathVariable Long id) {
        try {
            serviceRecordService.deleteServiceRecord(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.NOT_FOUND);
        }
    }

    public static class ErrorResponse {
        public String message;
        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}
