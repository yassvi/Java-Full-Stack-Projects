package com.example.project.controller;

import com.example.project.dto.MaintenancePredictionResponse;
import com.example.project.service.MaintenancePredictionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/prediction")
@CrossOrigin(origins = "*", maxAge = 3600)
public class MaintenancePredictionController {

    @Autowired
    private MaintenancePredictionService predictionService;

    @GetMapping("/{vehicleId}")
    public ResponseEntity<?> predictMaintenance(@PathVariable Long vehicleId) {
        try {
            MaintenancePredictionResponse prediction = predictionService.predictMaintenance(vehicleId);
            return new ResponseEntity<>(prediction, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.NOT_FOUND);
        }
    }

    public static class ErrorResponse {
        public String message;
        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}
