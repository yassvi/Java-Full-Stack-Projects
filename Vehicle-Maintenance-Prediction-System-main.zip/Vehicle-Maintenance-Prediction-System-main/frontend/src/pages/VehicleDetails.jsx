import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { vehicleAPI, serviceAPI } from '../services/api';
import { formatDate, formatKilometers, showAlert } from '../utils/helpers';

const VehicleDetails = () => {
  const { vehicleId } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState(null);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddService, setShowAddService] = useState(false);
  const [serviceForm, setServiceForm] = useState({
    serviceDate: '',
    kmAtService: '',
    serviceType: '',
    notes: '',
  });
  const [serviceErrors, setServiceErrors] = useState({});

  useEffect(() => {
    fetchData();
  }, [vehicleId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const vehicleRes = await vehicleAPI.getById(vehicleId);
      setVehicle(vehicleRes.data);

      const servicesRes = await serviceAPI.getByVehicle(vehicleId);
      setServices(servicesRes.data);
    } catch (error) {
      showAlert('Failed to load vehicle details', 'error');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleServiceFormChange = (e) => {
    const { name, value } = e.target;
    setServiceForm((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (serviceErrors[name]) {
      setServiceErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const validateServiceForm = () => {
    const newErrors = {};

    if (!serviceForm.serviceDate) {
      newErrors.serviceDate = 'Service date is required';
    }
    if (!serviceForm.kmAtService || isNaN(serviceForm.kmAtService) || serviceForm.kmAtService < 0) {
      newErrors.kmAtService = 'Please enter valid kilometers';
    }
    if (!serviceForm.serviceType.trim()) {
      newErrors.serviceType = 'Service type is required';
    }

    return newErrors;
  };

  const handleAddService = async (e) => {
    e.preventDefault();
    const newErrors = validateServiceForm();

    if (Object.keys(newErrors).length > 0) {
      setServiceErrors(newErrors);
      return;
    }

    try {
      await serviceAPI.create(vehicleId, {
        serviceDate: serviceForm.serviceDate,
        kmAtService: parseInt(serviceForm.kmAtService),
        serviceType: serviceForm.serviceType,
        notes: serviceForm.notes,
      });

      showAlert('Service record added successfully!', 'success');
      setServiceForm({
        serviceDate: '',
        kmAtService: '',
        serviceType: '',
        notes: '',
      });
      setShowAddService(false);
      fetchData();
    } catch (error) {
      showAlert(error.response?.data?.message || 'Failed to add service record', 'error');
    }
  };

  const handleDeleteService = async (serviceId) => {
    if (window.confirm('Are you sure you want to delete this service record?')) {
      try {
        await serviceAPI.delete(serviceId);
        setServices(services.filter((s) => s.id !== serviceId));
        showAlert('Service record deleted successfully', 'success');
      } catch (error) {
        showAlert('Failed to delete service record', 'error');
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading vehicle details...</p>
        </div>
      </div>
    );
  }

  if (!vehicle) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Vehicle not found</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-blue-600 hover:text-blue-800 font-semibold"
          >
            ← Back to Dashboard
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Vehicle Info */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{vehicle.name}</h1>
              <div className="space-y-2 text-gray-600">
                <p>
                  <span className="font-semibold">Model:</span> {vehicle.model}
                </p>
                <p>
                  <span className="font-semibold">Fuel Type:</span> {vehicle.fuelType}
                </p>
                <p>
                  <span className="font-semibold">Purchase Date:</span> {formatDate(vehicle.purchaseDate)}
                </p>
                <p>
                  <span className="font-semibold">Current KM:</span> {formatKilometers(vehicle.kmDriven)}
                </p>
              </div>
            </div>

            <div className="flex items-end gap-4">
              <button
                onClick={() => navigate(`/prediction/${vehicleId}`)}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition"
              >
                View Maintenance Prediction
              </button>
              <button
                onClick={() => navigate(`/fuel/${vehicleId}`)}
                className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-lg font-semibold transition"
              >
                Open Fuel Tracker
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Fuel Efficiency Tracker</h2>
          <p className="text-gray-600 mb-4">
            Track fuel fills and auto-calculate mileage in km/l for this vehicle.
          </p>
          <button
            onClick={() => navigate(`/fuel/${vehicleId}`)}
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg font-semibold transition"
          >
            Manage Fuel Records
          </button>
        </div>

        {/* Service History */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Service History</h2>
            <button
              onClick={() => setShowAddService(!showAddService)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition text-sm"
            >
              {showAddService ? '✕ Close' : '+ Add Service'}
            </button>
          </div>

          {showAddService && (
            <div className="px-6 py-6 border-b border-gray-200 bg-blue-50">
              <form onSubmit={handleAddService} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service Date</label>
                    <input
                      type="date"
                      name="serviceDate"
                      value={serviceForm.serviceDate}
                      onChange={handleServiceFormChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        serviceErrors.serviceDate ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {serviceErrors.serviceDate && (
                      <p className="text-red-500 text-sm mt-1">{serviceErrors.serviceDate}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">KM at Service</label>
                    <input
                      type="number"
                      name="kmAtService"
                      value={serviceForm.kmAtService}
                      onChange={handleServiceFormChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        serviceErrors.kmAtService ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="e.g., 10000"
                      min="0"
                    />
                    {serviceErrors.kmAtService && (
                      <p className="text-red-500 text-sm mt-1">{serviceErrors.kmAtService}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Service Type</label>
                  <input
                    type="text"
                    name="serviceType"
                    value={serviceForm.serviceType}
                    onChange={handleServiceFormChange}
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      serviceErrors.serviceType ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="e.g., Oil Change, General Service"
                  />
                  {serviceErrors.serviceType && (
                    <p className="text-red-500 text-sm mt-1">{serviceErrors.serviceType}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes (Optional)</label>
                  <textarea
                    name="notes"
                    value={serviceForm.notes}
                    onChange={handleServiceFormChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="3"
                    placeholder="Add any notes about the service"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition"
                >
                  Add Service Record
                </button>
              </form>
            </div>
          )}

          {services.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-gray-600">No service records yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      KM
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Service Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Notes
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {services.map((service) => (
                    <tr key={service.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-semibold">
                        {formatDate(service.serviceDate)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {formatKilometers(service.kmAtService)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">{service.serviceType}</td>
                      <td className="px-6 py-4 text-gray-600 max-w-xs truncate">{service.notes}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => handleDeleteService(service.id)}
                          className="text-red-600 hover:text-red-800 font-semibold text-sm"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default VehicleDetails;
