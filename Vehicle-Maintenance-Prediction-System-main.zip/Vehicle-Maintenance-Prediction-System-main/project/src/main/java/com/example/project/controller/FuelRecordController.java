package com.example.project.controller;

import com.example.project.dto.FuelRecordDTO;
import com.example.project.service.FuelRecordService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fuel")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FuelRecordController {

    @Autowired
    private FuelRecordService fuelRecordService;

    @PostMapping("/{vehicleId}")
    public ResponseEntity<?> addFuelRecord(
            @PathVariable Long vehicleId,
            @Valid @RequestBody FuelRecordDTO dto) {
        try {
            FuelRecordDTO created = fuelRecordService.addFuelRecord(vehicleId, dto);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{vehicleId}")
    public ResponseEntity<?> getFuelRecords(@PathVariable Long vehicleId) {
        try {
            List<FuelRecordDTO> records = fuelRecordService.getFuelRecordsByVehicle(vehicleId);
            return new ResponseEntity<>(records, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    public static class ErrorResponse {
        public String message;

        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}
