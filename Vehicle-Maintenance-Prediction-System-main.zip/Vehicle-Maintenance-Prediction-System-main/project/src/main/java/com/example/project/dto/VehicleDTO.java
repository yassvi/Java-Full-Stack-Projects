package com.example.project.dto;

import com.example.project.entity.Vehicle;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {

    private Long id;

    @NotBlank(message = "Vehicle name is required")
    private String name;

    @NotBlank(message = "Model is required")
    private String model;

    @NotNull(message = "Fuel type is required")
    private Vehicle.FuelType fuelType;

    @NotNull(message = "Purchase date is required")
    @PastOrPresent(message = "Purchase date cannot be in the future")
    private LocalDate purchaseDate;

    @NotNull(message = "KM driven is required")
    @Min(value = 0, message = "KM driven cannot be negative")
    private Long kmDriven;

    public static VehicleDTO fromEntity(Vehicle vehicle) {
        return new VehicleDTO(
                vehicle.getId(),
                vehicle.getName(),
                vehicle.getModel(),
                vehicle.getFuelType(),
                vehicle.getPurchaseDate(),
                vehicle.getKmDriven()
        );
    }
}
