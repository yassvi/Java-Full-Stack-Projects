import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { fuelAPI, vehicleAPI } from '../services/api';
import { formatDate, showAlert } from '../utils/helpers';

const FuelTracker = () => {
  const { vehicleId } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState(null);
  const [fuelRecords, setFuelRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    fuelDate: '',
    liters: '',
    odometerReading: '',
  });

  useEffect(() => {
    fetchFuelData();
  }, [vehicleId]);

  const fetchFuelData = async () => {
    try {
      setLoading(true);
      const vehicleRes = await vehicleAPI.getById(vehicleId);
      setVehicle(vehicleRes.data);

      const recordsRes = await fuelAPI.getByVehicle(vehicleId);
      setFuelRecords(recordsRes.data);
    } catch (error) {
      showAlert('Failed to load fuel tracker data', 'error');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.fuelDate) {
      newErrors.fuelDate = 'Fuel date is required';
    }

    const liters = Number(formData.liters);
    if (!formData.liters || Number.isNaN(liters) || liters <= 0) {
      newErrors.liters = 'Liters must be greater than 0';
    }

    const odometer = Number(formData.odometerReading);
    if (!formData.odometerReading || Number.isNaN(odometer) || odometer < 0) {
      newErrors.odometerReading = 'Odometer reading cannot be negative';
    }

    if (fuelRecords.length > 0 && !newErrors.odometerReading) {
      const highestOdometer = Math.max(...fuelRecords.map((record) => Number(record.odometerReading)));
      if (odometer <= highestOdometer) {
        newErrors.odometerReading = 'Odometer reading must be greater than previous entry';
      }
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      await fuelAPI.create(vehicleId, {
        fuelDate: formData.fuelDate,
        liters: Number(formData.liters),
        odometerReading: Number(formData.odometerReading),
      });

      showAlert('Fuel record added successfully!', 'success');
      setFormData({ fuelDate: '', liters: '', odometerReading: '' });
      fetchFuelData();
    } catch (error) {
      showAlert(error.response?.data?.message || 'Failed to add fuel record', 'error');
    }
  };

  const getMileageCellClass = (mileage) => {
    if (mileage > 18) {
      return 'text-green-700 bg-green-50';
    }
    if (mileage >= 12) {
      return 'text-yellow-700 bg-yellow-50';
    }
    return 'text-red-700 bg-red-50';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading fuel tracker...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(`/vehicle/${vehicleId}`)}
            className="text-blue-600 hover:text-blue-800 font-semibold"
          >
            ← Back to Vehicle Details
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Fuel Efficiency Tracker</h1>
          <p className="text-gray-600">{vehicle?.name} - {vehicle?.model}</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Add Fuel Entry</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  name="fuelDate"
                  value={formData.fuelDate}
                  onChange={handleFormChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.fuelDate ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {errors.fuelDate && <p className="text-red-500 text-sm mt-1">{errors.fuelDate}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Liters</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  name="liters"
                  value={formData.liters}
                  onChange={handleFormChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.liters ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="e.g., 20"
                />
                {errors.liters && <p className="text-red-500 text-sm mt-1">{errors.liters}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Odometer Reading (km)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  name="odometerReading"
                  value={formData.odometerReading}
                  onChange={handleFormChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.odometerReading ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="e.g., 10250"
                />
                {errors.odometerReading && (
                  <p className="text-red-500 text-sm mt-1">{errors.odometerReading}</p>
                )}
              </div>
            </div>

            <button
              type="submit"
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2 rounded-lg font-semibold transition"
            >
              Save Fuel Entry
            </button>
          </form>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Fuel Records</h2>
          </div>

          {fuelRecords.length === 0 ? (
            <div className="px-6 py-10 text-center text-gray-600">No fuel entries yet</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Liters
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Odometer
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                      Mileage (km/l)
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {fuelRecords.map((record) => (
                    <tr key={record.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-semibold">
                        {formatDate(record.fuelDate)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {Number(record.liters).toFixed(2)} L
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {Number(record.odometerReading).toLocaleString()} km
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {record.mileage > 0 ? (
                          <span className={`px-3 py-1 rounded-full font-semibold ${getMileageCellClass(record.mileage)}`}>
                            {Number(record.mileage).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default FuelTracker;
